import CSP.CSP;
import CSP.Constraint;
import CSP.Futoshiki.FutoshikiCSP;
import CSP.Futoshiki.RowConstraint;
import CSP.Futoshiki.Utils;

import java.awt.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidAlgorithmParameterException;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.List;
import java.util.stream.IntStream;

public class FutoshikiMain {

    public static void main(String[] args) {
        try {
            List<FutoshikiCSP> futoshikiCSPS = List.of(new FutoshikiCSP(Path.of("binary-futoshiki_dane_v1.0/futoshiki_4x4"), 4),
                    new FutoshikiCSP(Path.of("binary-futoshiki_dane_v1.0/futoshiki_5x5"), 5),
                    new FutoshikiCSP(Path.of("binary-futoshiki_dane_v1.0/futoshiki_6x6"), 6)
                    );
            futoshikiCSPS.forEach( futoshiki ->{
                var results = futoshiki.backtrackingSearch();
                for(var res : results){
                    Utils.printArray(Utils.mapAsArray(res, futoshiki.getSize()));
                    System.out.println("\n-----------\n");
                }
            });
        } catch (InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        }
    }
}
