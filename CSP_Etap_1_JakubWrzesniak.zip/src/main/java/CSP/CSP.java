package CSP;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.List;

public class CSP <V, D>{
    private final List<V>                        variables;
    private final Map<V, List<D>>                domains;
    private final Map<V, List<Constraint<V, D>>> constraints;
    private List<Map<V,D>>                 results;

    public CSP(List<V> variables, Map<V, List<D>> domains) {
        this.variables = variables;
        this.domains = domains;
        constraints = new HashMap<>();
        for (V variable : variables) {
            constraints.put(variable, new ArrayList<>());
            if (!domains.containsKey(variable)) {
                throw new IllegalArgumentException("Every variable should have a domain assigned to it.");
            }
        }
    }

    public void addConstraint(Constraint<V, D> constraint){
        for(V variable: constraint.variables){
            if(!variables.contains(variable)){
                throw new IllegalArgumentException("Variable in constraint not in CSP");
            } else {
                constraints.get(variable).add(constraint);
            }
        }
    }

    public boolean consistent(V variable, Map<V, D> assignment){
        return constraints.get(variable).stream().allMatch(v -> v.satisfied(assignment));
    }

    public List<Map<V,D>> backtrackingSearch(Map<V,D> assignment){
        results = new ArrayList<>();
        var values = assignment.keySet();
        var filteredAssignment = variables.stream().filter(v -> !values.contains(v)).toList();
        Instant start = Instant.now();
        backtrackingSearch(assignment, new LinkedList<>(filteredAssignment));
        Instant  end         = Instant.now();
        Duration timeElapsed = Duration.between(start, end);
        System.out.println(Timestamp.from(Instant.now()) + " Finished Backtracking in " + timeElapsed.toMillis() + " milliseconds");
        return results;
    }

    private void backtrackingSearch(Map<V,D> assignment, LinkedList<V> unassignedVariables) {
        if(unassignedVariables.isEmpty()) {
            System.out.println(Timestamp.from(Instant.now()) + " - Found new result: " + (results.size() + 1));
            this.results.add(assignment);
            return;
        }
        V unassigned = unassignedVariables.pop();
        for(D value : domains.get(unassigned)){
            Map<V, D> localAssignment = new HashMap<>(assignment);
            localAssignment.put(unassigned, value);
            if(consistent(unassigned, localAssignment))
               backtrackingSearch(localAssignment, unassignedVariables);
        }
        unassignedVariables.push(unassigned);
    }
}
